/*
============================================================================
Name : 15.c
Author : Sudhanshu Sathawane
Description : Write a program to display the environmental variable of the user (use environ).
Date: 25th Aug, 2023.
============================================================================
*/
#include<stdio.h>
void main(int argc, char *argv[],char * envp[]){
	int i;
	for(int i=0;envp[i]!=NULL;i++){
		printf("\n%s",envp[i]);
	}
}

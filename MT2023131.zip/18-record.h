// Structure of a record - Example: "10" means record 1 has some number 0
struct record
{
    int recordNumber;
    int someNumber; 
};

char *filename = "./sample-files/18-file"; // Name of the file used for storing records
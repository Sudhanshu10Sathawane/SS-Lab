#!/bin/bash

echo "Script run at `date`" >> 30_script_output
